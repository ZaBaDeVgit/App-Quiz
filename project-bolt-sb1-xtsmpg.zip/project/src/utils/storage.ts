import { Question, TestResult } from '../types';

export const getStoredQuestions = (): Question[] => {
  return JSON.parse(localStorage.getItem('questions') || '[]');
};

export const saveQuestion = (question: Question): void => {
  const questions = getStoredQuestions();
  localStorage.setItem('questions', JSON.stringify([...questions, question]));
};

export const getStoredResults = (): TestResult[] => {
  return JSON.parse(localStorage.getItem('testResults') || '[]');
};

export const saveTestResult = (result: TestResult): void => {
  const results = getStoredResults();
  localStorage.setItem('testResults', JSON.stringify([...results, result]));
};

export const getFilteredQuestions = (category: string, topic: string): Question[] => {
  return getStoredQuestions().filter(
    (q) => q.category === category && q.topic === topic
  );
};