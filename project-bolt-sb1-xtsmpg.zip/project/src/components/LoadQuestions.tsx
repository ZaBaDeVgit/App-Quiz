import { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Question } from '../types';
import { saveQuestion } from '../utils/storage';

export default function LoadQuestions() {
  const navigate = useNavigate();
  const [category, setCategory] = useState('');
  const [topic, setTopic] = useState('');
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '', '', '']);
  const [correctAnswer, setCorrectAnswer] = useState<number | null>(null);
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!category || !topic || !question || options.some(opt => !opt) || correctAnswer === null) {
      setMessage('Por favor, completa todos los campos y selecciona la respuesta correcta');
      return;
    }

    const newQuestion: Question = {
      category,
      topic,
      question,
      options,
      correct: correctAnswer
    };

    saveQuestion(newQuestion);

    setCategory('');
    setTopic('');
    setQuestion('');
    setOptions(['', '', '', '']);
    setCorrectAnswer(null);
    setMessage('¡Pregunta guardada correctamente!');

    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-4xl"
      >
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => navigate('/')}
            className="flex items-center text-white hover:text-purple-300 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 mr-2" />
            Volver al Menú
          </button>
        </div>

        <h2 className="text-4xl font-bold text-white mb-8 text-center">
          Cargar Nuevas Preguntas
        </h2>

        {message && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`p-4 rounded-lg mb-6 text-center ${
              message.includes('Por favor')
                ? 'bg-red-500 bg-opacity-20 text-red-100'
                : 'bg-green-500 bg-opacity-20 text-green-100'
            }`}
          >
            {message}
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-white text-lg">Categoría</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="Nueva o existente"
              />
            </div>
            <div className="space-y-2">
              <label className="text-white text-lg">Tema</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full p-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="Nuevo o existente"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-white text-lg">Pregunta</label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="w-full p-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              rows={3}
              placeholder="Escribe la pregunta aquí"
            />
          </div>

          <div className="space-y-4">
            <label className="text-white text-lg">Opciones</label>
            {options.map((option, index) => (
              <div key={index} className="flex items-center space-x-4">
                <input
                  type="radio"
                  name="correctAnswer"
                  checked={correctAnswer === index}
                  onChange={() => setCorrectAnswer(index)}
                  className="w-5 h-5 text-purple-600"
                />
                <input
                  type="text"
                  value={option}
                  onChange={(e) => {
                    const newOptions = [...options];
                    newOptions[index] = e.target.value;
                    setOptions(newOptions);
                  }}
                  className="flex-1 p-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder={`Opción ${index + 1}${correctAnswer === index ? ' (Correcta)' : ''}`}
                />
              </div>
            ))}
          </div>

          <div className="flex justify-end space-x-4">
            <motion.button
              type="submit"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-3 rounded-lg text-white font-bold shadow-lg hover:shadow-xl transition-all"
            >
              <Save className="w-5 h-5" />
              <span>Guardar Pregunta</span>
            </motion.button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}