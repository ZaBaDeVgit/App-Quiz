import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Categories, Question, TestResult } from '../types';
import { getFilteredQuestions, saveTestResult } from '../utils/storage';

const categories: Categories = {
  'Programación': ['JavaScript', 'Python', 'React'],
  'Historia': ['Antigua', 'Medieval', 'Moderna'],
  'Ciencia': ['Física', 'Química', 'Biología']
};

export default function TestSection() {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [testStarted, setTestStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);

  const finishTest = useCallback(() => {
    setTestStarted(false);
    setIsTimerRunning(false);
    
    const result: TestResult = {
      category: selectedCategory,
      topic: selectedTopic,
      score,
      total: questions.length,
      date: new Date().toISOString().split('T')[0]
    };

    saveTestResult(result);
    navigate('/scores');
  }, [selectedCategory, selectedTopic, score, questions.length, navigate]);

  useEffect(() => {
    if (testStarted && timeLeft > 0 && isTimerRunning) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);

      return () => clearInterval(timer);
    } else if (timeLeft === 0 && testStarted) {
      finishTest();
    }
  }, [timeLeft, testStarted, isTimerRunning, finishTest]);

  const startTest = () => {
    const filteredQuestions = getFilteredQuestions(selectedCategory, selectedTopic);

    if (filteredQuestions.length === 0) {
      alert('No hay preguntas disponibles para esta categoría y tema');
      return;
    }

    setQuestions(filteredQuestions);
    setTestStarted(true);
    setIsTimerRunning(true);
    setTimeLeft(30);
    setScore(0);
    setCurrentQuestion(0);
  };

  const handleAnswer = (selectedIndex: number) => {
    if (selectedIndex === questions[currentQuestion].correct) {
      setScore((prev) => prev + 1);
    }

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
      setTimeLeft(30);
    } else {
      finishTest();
    }
  };

  const goBack = () => {
    if (testStarted) {
      if (window.confirm('¿Estás seguro de que quieres abandonar el test?')) {
        setTestStarted(false);
        setSelectedTopic('');
      }
    } else if (selectedTopic) {
      setSelectedTopic('');
    } else if (selectedCategory) {
      setSelectedCategory('');
    } else {
      navigate('/');
    }
  };

  if (!selectedCategory) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-4xl"
        >
          <div className="flex justify-between items-center mb-8">
            <button
              onClick={goBack}
              className="flex items-center text-white hover:text-purple-300 transition-colors"
            >
              <ArrowLeft className="w-6 h-6 mr-2" />
              Volver al Menú
            </button>
          </div>

          <h2 className="text-4xl font-bold text-white mb-8 text-center">
            Selecciona una Categoría
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.keys(categories).map((category) => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 rounded-xl text-white text-xl font-bold shadow-lg hover:shadow-xl transition-all"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  if (!selectedTopic) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-4xl"
        >
          <div className="flex justify-between items-center mb-8">
            <button
              onClick={goBack}
              className="flex items-center text-white hover:text-purple-300 transition-colors"
            >
              <ArrowLeft className="w-6 h-6 mr-2" />
              Volver a Categorías
            </button>
          </div>

          <h2 className="text-4xl font-bold text-white mb-8 text-center">
            Selecciona un Tema
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {categories[selectedCategory].map((topic) => (
              <motion.button
                key={topic}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 p-6 rounded-xl text-white text-xl font-bold shadow-lg hover:shadow-xl transition-all"
                onClick={() => {
                  setSelectedTopic(topic);
                  startTest();
                }}
              >
                {topic}
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-4xl">
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={goBack}
            className="flex items-center text-white hover:text-purple-300 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 mr-2" />
            Abandonar Test
          </button>
        </div>
        <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-8">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center text-white">
              <Clock className="w-6 h-6 mr-2 animate-pulse" />
              <span className="text-2xl">Tiempo: {timeLeft}s</span>
            </div>
            <div className="text-white">
              <span className="text-2xl">Pregunta {currentQuestion + 1}/{questions.length}</span>
            </div>
            <div className="text-white">
              <span className="text-2xl">Puntuación: {score}</span>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-3xl font-bold text-white mb-4">
              {questions[currentQuestion]?.question}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {questions[currentQuestion]?.options.map((option, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 p-4 rounded-lg text-white text-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all"
                  onClick={() => handleAnswer(index)}
                >
                  {option}
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}